import os

os.system("sudo brew install ruby")
os.system("sudo brew install rbenv")
os.system("sudo brew install rake")
os.system("sudo brew install execjs")
